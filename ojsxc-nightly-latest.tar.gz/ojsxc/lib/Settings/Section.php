<?php

namespace OCA\OJSXC\Settings;

use OCP\IL10N;
use OCP\IURLGenerator;
use OCP\Settings\ISection;

class SectionBase implements ISection
{
	/** @var IL10N */
	private $l;

	/** @var IURLGenerator */
	private $url;

	public function __construct(IL10N $l, IURLGenerator $url)
	{
		$this->l = $l;
		$this->url = $url;
	}

	/**
	 * returns the ID of the section. It is supposed to be a lower case string,
	 * e.g. 'ldap'
	 *
	 * @returns string
	 */
	public function getID()
	{
		return 'ojsxc';
	}

	/**
	 * returns the translated name as it should be displayed, e.g. 'LDAP / AD
	 * integration'. Use the L10N service to translate it.
	 *
	 * @return string
	 */
	public function getName()
	{
		return 'JavaScript XMPP Client';
	}

	/**
	 * @return int whether the form should be rather on the top or bottom of
	 * the settings navigation. The sections are arranged in ascending order of
	 * the priority values. It is required to return a value between 0 and 99.
	 *
	 * E.g.: 70
	 */
	public function getPriority()
	{
		return 50;
	}

	/**
	 * {@inheritdoc}
	 */
	public function getIcon()
	{
		return $this->url->imagePath('ojsxc', 'app-black.svg');
	}
}

$version = \OCP\Util::getVersion();
if ($version[0] >= 12) {
	class Section extends SectionBase implements \OCP\Settings\IIconSection
	{
	}
} else {
	class Section extends SectionBase
	{
	}
}
