<?php

namespace OCA\OJSXC;

interface IDataRetriever
{
	public function fetchUrl($url, $data);
}
