<?php

namespace OCA\OJSXC\Controller;

use OCP\AppFramework\ApiController;

abstract class SignatureProtectedApiController extends ApiController
{
}
