<?php

namespace OCA\OJSXC\Exceptions;

class UnprocessableException extends Exception
{
}
