<?php

namespace OCA\OJSXC\Exceptions;

class SecurityException extends Exception
{
}
