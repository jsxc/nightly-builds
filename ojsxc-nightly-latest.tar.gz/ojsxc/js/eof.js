/*!
 * ojsxc vnightly.20170901-d010dd9 - 2017-09-01
 * 
 * Copyright (c) 2017 Klaus Herberth <klaus@jsxc.org> <br>
 * Released under the MIT license
 * 
 * Please see http://www.jsxc.org/
 * 
 * @author Klaus Herberth <klaus@jsxc.org>
 * @version nightly.20170901-d010dd9
 * @license MIT
 */

/**
 * This is a helper file for the concatenation.
 */
;